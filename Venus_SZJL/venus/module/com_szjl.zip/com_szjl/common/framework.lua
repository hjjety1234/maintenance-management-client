-- -----------------------------------------------------------------------------
-- | WonderTek [ 网络无处不在，沟通及时到达 ]
-- -----------------------------------------------------------------------------
-- | Copyright (c) 2012, WonderTek, Inc. All Rights Reserved.
-- -----------------------------------------------------------------------------
-- | Author: xxxx <xxxx@xxxx.com>
-- -----------------------------------------------------------------------------
-- | Desc: 框架包含
-- -----------------------------------------------------------------------------

require 'framework.common'
require 'com_szjl.common.defines'
require 'com_szjl.common.util'
require 'com_szjl.common.scene'
require 'com_szjl.common.loading'
require 'com_szjl.common.upload'
require 'com_szjl.common.config'
require 'com_szjl.common.map'
require 'com_szjl.common.dialog'
require 'com_szjl.common.menu'
require 'com_szjl.common.umsagent'
