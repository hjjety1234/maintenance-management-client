-- -----------------------------------------------------------------------------
-- | WonderTek [ 网络无处不在，沟通及时到达 ]
-- -----------------------------------------------------------------------------
-- | Copyright (c) 2012, WonderTek, Inc. All Rights Reserved.
-- -----------------------------------------------------------------------------
-- | Author: xxxx <xxxx@xxxx.com>
-- -----------------------------------------------------------------------------
-- | Desc: 框架包含
-- -----------------------------------------------------------------------------

require 'framework.common'
require 'com_xsgj.common.defines'
require 'com_xsgj.common.util'
require 'com_xsgj.common.scene'
require 'com_xsgj.common.dialog'
require 'com_xsgj.common.loading'
require 'com_xsgj.common.config'
require 'com_xsgj.common.menu'
