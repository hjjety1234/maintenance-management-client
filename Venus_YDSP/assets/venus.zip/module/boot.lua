entrance = 'com_wondertek_cnlive2' 
